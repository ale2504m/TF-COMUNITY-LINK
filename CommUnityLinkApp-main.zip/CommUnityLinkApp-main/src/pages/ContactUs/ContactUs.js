import React from "react";
import "./style.css";
import Navbar from "../../components/shared/Navbar";

export const ContactUs = () => {
  return (
    <div>
        <Navbar/>
    </div>
  );
}